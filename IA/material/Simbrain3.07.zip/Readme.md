## Simbrain 3.06

For release notes see the Readme.md file for `Simbrain4` branch, which is the default readme 
[here](https://github.com/simbrain/simbrain/tree/Simbrain4)