R and python scripts used to prepare the backprop_cars.bsh script.  Run the R script first, then the python script.

The R script was used to get the car data, and also has some code to analyze it. 

The pythong script was used to rescale the data and split it in to training and test sets.